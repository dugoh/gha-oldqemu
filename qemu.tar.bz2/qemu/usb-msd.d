usb-msd.o: /tmp/qemu/hw/usb-msd.c qemu-common.h config-host.h osdep.h \
 bswap.h module.h /tmp/qemu/hw/usb.h block.h qemu-aio.h qemu-common.h \
 qemu-char.h sys-queue.h qemu-option.h /tmp/qemu/hw/scsi-disk.h console.h
qemu-common.h:
config-host.h:
osdep.h:
bswap.h:
module.h:
/tmp/qemu/hw/usb.h:
block.h:
qemu-aio.h:
qemu-common.h:
qemu-char.h:
sys-queue.h:
qemu-option.h:
/tmp/qemu/hw/scsi-disk.h:
console.h:
