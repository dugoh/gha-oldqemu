irq.o: /tmp/qemu/hw/irq.c qemu-common.h config-host.h osdep.h bswap.h \
 module.h /tmp/qemu/hw/irq.h
qemu-common.h:
config-host.h:
osdep.h:
bswap.h:
module.h:
/tmp/qemu/hw/irq.h:
