stellaris_input.o: /tmp/qemu/hw/stellaris_input.c /tmp/qemu/hw/hw.h \
 qemu-common.h config-host.h osdep.h bswap.h module.h ioport.h \
 qemu-common.h /tmp/qemu/hw/irq.h /tmp/qemu/hw/devices.h console.h \
 qemu-char.h sys-queue.h
/tmp/qemu/hw/hw.h:
qemu-common.h:
config-host.h:
osdep.h:
bswap.h:
module.h:
ioport.h:
qemu-common.h:
/tmp/qemu/hw/irq.h:
/tmp/qemu/hw/devices.h:
console.h:
qemu-char.h:
sys-queue.h:
