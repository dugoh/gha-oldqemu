pcspk.o: /tmp/qemu/hw/pcspk.c /tmp/qemu/hw/hw.h ../qemu-common.h \
 ../config-host.h /tmp/qemu/target-i386/cpu.h config.h ../config-host.h \
 ../cpu-defs.h ../osdep.h ../sys-queue.h ../targphys.h \
 /tmp/qemu/fpu/softfloat.h /tmp/qemu/fpu/softfloat-native.h ../cpu-all.h \
 ../qemu-common.h ../cpu-common.h ../bswap.h ../ioport.h ../exec-all.h \
 ../qemu-log.h ../qemu-lock.h ../softmmu_defs.h ../softmmu_header.h \
 /tmp/qemu/target-i386/svm.h ../module.h ../ioport.h /tmp/qemu/hw/irq.h \
 /tmp/qemu/hw/pc.h /tmp/qemu/hw/isa.h ../audio/audio.h ../config-host.h \
 ../sys-queue.h ../qemu-timer.h
/tmp/qemu/hw/hw.h:
../qemu-common.h:
../config-host.h:
/tmp/qemu/target-i386/cpu.h:
config.h:
../config-host.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../cpu-common.h:
../bswap.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
../module.h:
../ioport.h:
/tmp/qemu/hw/irq.h:
/tmp/qemu/hw/pc.h:
/tmp/qemu/hw/isa.h:
../audio/audio.h:
../config-host.h:
../sys-queue.h:
../qemu-timer.h:
