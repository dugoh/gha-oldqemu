ide.o: /tmp/qemu/hw/ide.c /tmp/qemu/hw/hw.h ../qemu-common.h \
 ../config-host.h /tmp/qemu/target-i386/cpu.h config.h ../config-host.h \
 ../cpu-defs.h ../osdep.h ../sys-queue.h ../targphys.h \
 /tmp/qemu/fpu/softfloat.h /tmp/qemu/fpu/softfloat-native.h ../cpu-all.h \
 ../qemu-common.h ../cpu-common.h ../bswap.h ../ioport.h ../exec-all.h \
 ../qemu-log.h ../qemu-lock.h ../softmmu_defs.h ../softmmu_header.h \
 /tmp/qemu/target-i386/svm.h ../module.h ../ioport.h /tmp/qemu/hw/irq.h \
 /tmp/qemu/hw/pc.h /tmp/qemu/hw/pci.h /tmp/qemu/hw/qdev.h ../sys-queue.h \
 /tmp/qemu/hw/isa.h /tmp/qemu/hw/pci_ids.h /tmp/qemu/hw/scsi-disk.h \
 /tmp/qemu/hw/pcmcia.h ../block.h ../qemu-aio.h ../qemu-char.h \
 ../qemu-option.h ../block_int.h ../block.h ../qemu-timer.h ../sysemu.h \
 /tmp/qemu/hw/ppc_mac.h /tmp/qemu/hw/mac_dbdma.h /tmp/qemu/hw/sh.h \
 /tmp/qemu/hw/sh_intc.h ../dma.h ../hw/hw.h
/tmp/qemu/hw/hw.h:
../qemu-common.h:
../config-host.h:
/tmp/qemu/target-i386/cpu.h:
config.h:
../config-host.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../cpu-common.h:
../bswap.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
../module.h:
../ioport.h:
/tmp/qemu/hw/irq.h:
/tmp/qemu/hw/pc.h:
/tmp/qemu/hw/pci.h:
/tmp/qemu/hw/qdev.h:
../sys-queue.h:
/tmp/qemu/hw/isa.h:
/tmp/qemu/hw/pci_ids.h:
/tmp/qemu/hw/scsi-disk.h:
/tmp/qemu/hw/pcmcia.h:
../block.h:
../qemu-aio.h:
../qemu-char.h:
../qemu-option.h:
../block_int.h:
../block.h:
../qemu-timer.h:
../sysemu.h:
/tmp/qemu/hw/ppc_mac.h:
/tmp/qemu/hw/mac_dbdma.h:
/tmp/qemu/hw/sh.h:
/tmp/qemu/hw/sh_intc.h:
../dma.h:
../hw/hw.h:
