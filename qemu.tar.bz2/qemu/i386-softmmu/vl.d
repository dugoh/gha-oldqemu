vl.o: /tmp/qemu/vl.c /tmp/qemu/config-host.h /tmp/qemu/sys-queue.h \
 /tmp/qemu/hpet.h /tmp/qemu/hw/hw.h ../qemu-common.h ../config-host.h \
 /tmp/qemu/target-i386/cpu.h config.h ../config-host.h ../cpu-defs.h \
 ../osdep.h ../sys-queue.h ../targphys.h /tmp/qemu/fpu/softfloat.h \
 /tmp/qemu/fpu/softfloat-native.h ../cpu-all.h ../qemu-common.h \
 ../cpu-common.h ../bswap.h ../ioport.h ../exec-all.h ../qemu-log.h \
 ../qemu-lock.h ../softmmu_defs.h ../softmmu_header.h \
 /tmp/qemu/target-i386/svm.h ../module.h ../ioport.h /tmp/qemu/hw/irq.h \
 /tmp/qemu/hw/boards.h /tmp/qemu/hw/qdev.h /tmp/qemu/hw/hw.h \
 ../sys-queue.h /tmp/qemu/hw/usb.h ../block.h ../qemu-aio.h \
 ../qemu-char.h ../qemu-option.h /tmp/qemu/hw/pcmcia.h /tmp/qemu/hw/pc.h \
 /tmp/qemu/hw/audiodev.h /tmp/qemu/hw/isa.h /tmp/qemu/hw/baum.h \
 /tmp/qemu/hw/bt.h /tmp/qemu/hw/watchdog.h /tmp/qemu/hw/smbios.h \
 /tmp/qemu/hw/xen.h /tmp/qemu/bt-host.h /tmp/qemu/net.h \
 /tmp/qemu/qemu-common.h /tmp/qemu/monitor.h /tmp/qemu/qemu-char.h \
 /tmp/qemu/block.h /tmp/qemu/console.h /tmp/qemu/sysemu.h \
 /tmp/qemu/gdbstub.h /tmp/qemu/qemu-timer.h /tmp/qemu/cache-utils.h \
 /tmp/qemu/dma.h /tmp/qemu/audio/audio.h ../config-host.h \
 /tmp/qemu/migration.h /tmp/qemu/kvm.h /tmp/qemu/balloon.h \
 /tmp/qemu/cpu-defs.h /tmp/qemu/qemu-option.h /tmp/qemu/disas.h \
 /tmp/qemu/exec-all.h /tmp/qemu/qemu_socket.h /tmp/qemu/slirp/libslirp.h \
 qemu-options.h
/tmp/qemu/config-host.h:
/tmp/qemu/sys-queue.h:
/tmp/qemu/hpet.h:
/tmp/qemu/hw/hw.h:
../qemu-common.h:
../config-host.h:
/tmp/qemu/target-i386/cpu.h:
config.h:
../config-host.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../cpu-common.h:
../bswap.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
../module.h:
../ioport.h:
/tmp/qemu/hw/irq.h:
/tmp/qemu/hw/boards.h:
/tmp/qemu/hw/qdev.h:
/tmp/qemu/hw/hw.h:
../sys-queue.h:
/tmp/qemu/hw/usb.h:
../block.h:
../qemu-aio.h:
../qemu-char.h:
../qemu-option.h:
/tmp/qemu/hw/pcmcia.h:
/tmp/qemu/hw/pc.h:
/tmp/qemu/hw/audiodev.h:
/tmp/qemu/hw/isa.h:
/tmp/qemu/hw/baum.h:
/tmp/qemu/hw/bt.h:
/tmp/qemu/hw/watchdog.h:
/tmp/qemu/hw/smbios.h:
/tmp/qemu/hw/xen.h:
/tmp/qemu/bt-host.h:
/tmp/qemu/net.h:
/tmp/qemu/qemu-common.h:
/tmp/qemu/monitor.h:
/tmp/qemu/qemu-char.h:
/tmp/qemu/block.h:
/tmp/qemu/console.h:
/tmp/qemu/sysemu.h:
/tmp/qemu/gdbstub.h:
/tmp/qemu/qemu-timer.h:
/tmp/qemu/cache-utils.h:
/tmp/qemu/dma.h:
/tmp/qemu/audio/audio.h:
../config-host.h:
/tmp/qemu/migration.h:
/tmp/qemu/kvm.h:
/tmp/qemu/balloon.h:
/tmp/qemu/cpu-defs.h:
/tmp/qemu/qemu-option.h:
/tmp/qemu/disas.h:
/tmp/qemu/exec-all.h:
/tmp/qemu/qemu_socket.h:
/tmp/qemu/slirp/libslirp.h:
qemu-options.h:
