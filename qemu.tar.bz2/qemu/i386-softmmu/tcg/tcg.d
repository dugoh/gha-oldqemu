tcg/tcg.o: /tmp/qemu/tcg/tcg.c config.h ../config-host.h ../qemu-common.h \
 ../config-host.h /tmp/qemu/target-i386/cpu.h ../cpu-defs.h ../osdep.h \
 ../sys-queue.h ../targphys.h /tmp/qemu/fpu/softfloat.h \
 /tmp/qemu/fpu/softfloat-native.h ../cpu-all.h ../qemu-common.h \
 ../cpu-common.h ../bswap.h ../ioport.h ../exec-all.h ../qemu-log.h \
 ../qemu-lock.h ../softmmu_defs.h ../softmmu_header.h \
 /tmp/qemu/target-i386/svm.h ../module.h ../cache-utils.h \
 /tmp/qemu/tcg/tcg-op.h /tmp/qemu/tcg/tcg.h \
 /tmp/qemu/tcg/x86_64/tcg-target.h /tmp/qemu/tcg/tcg-opc.h ../elf.h \
 /tmp/qemu/tcg/x86_64/tcg-target.c \
 /tmp/qemu/tcg/x86_64/../../softmmu_defs.h
config.h:
../config-host.h:
../qemu-common.h:
../config-host.h:
/tmp/qemu/target-i386/cpu.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../cpu-common.h:
../bswap.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
../module.h:
../cache-utils.h:
/tmp/qemu/tcg/tcg-op.h:
/tmp/qemu/tcg/tcg.h:
/tmp/qemu/tcg/x86_64/tcg-target.h:
/tmp/qemu/tcg/tcg-opc.h:
../elf.h:
/tmp/qemu/tcg/x86_64/tcg-target.c:
/tmp/qemu/tcg/x86_64/../../softmmu_defs.h:
