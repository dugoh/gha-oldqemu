kqemu.o: /tmp/qemu/kqemu.c config.h ../config-host.h \
 /tmp/qemu/target-i386/cpu.h ../cpu-defs.h ../osdep.h ../sys-queue.h \
 ../targphys.h /tmp/qemu/fpu/softfloat.h /tmp/qemu/fpu/softfloat-native.h \
 ../cpu-all.h ../qemu-common.h ../config-host.h ../module.h \
 ../cpu-common.h ../bswap.h ../ioport.h ../exec-all.h ../qemu-log.h \
 ../qemu-lock.h ../softmmu_defs.h ../softmmu_header.h \
 /tmp/qemu/target-i386/svm.h /tmp/qemu/exec-all.h /tmp/qemu/qemu-common.h \
 /tmp/qemu/kqemu.h
config.h:
../config-host.h:
/tmp/qemu/target-i386/cpu.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../config-host.h:
../module.h:
../cpu-common.h:
../bswap.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
/tmp/qemu/exec-all.h:
/tmp/qemu/qemu-common.h:
/tmp/qemu/kqemu.h:
