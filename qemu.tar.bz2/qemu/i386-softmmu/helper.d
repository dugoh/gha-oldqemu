helper.o: /tmp/qemu/target-i386/helper.c /tmp/qemu/target-i386/cpu.h \
 config.h ../config-host.h ../cpu-defs.h ../osdep.h ../sys-queue.h \
 ../targphys.h /tmp/qemu/fpu/softfloat.h /tmp/qemu/fpu/softfloat-native.h \
 ../cpu-all.h ../qemu-common.h ../config-host.h \
 /tmp/qemu/target-i386/cpu.h ../module.h ../cpu-common.h ../bswap.h \
 ../ioport.h ../exec-all.h ../qemu-log.h ../qemu-lock.h ../softmmu_defs.h \
 ../softmmu_header.h /tmp/qemu/target-i386/svm.h ../qemu-common.h \
 ../kvm.h
/tmp/qemu/target-i386/cpu.h:
config.h:
../config-host.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../config-host.h:
/tmp/qemu/target-i386/cpu.h:
../module.h:
../cpu-common.h:
../bswap.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
../qemu-common.h:
../kvm.h:
