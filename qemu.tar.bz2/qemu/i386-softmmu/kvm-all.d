kvm-all.o: /tmp/qemu/kvm-all.c /tmp/qemu/qemu-common.h \
 /tmp/qemu/config-host.h /tmp/qemu/target-i386/cpu.h config.h \
 ../config-host.h ../cpu-defs.h ../osdep.h ../sys-queue.h ../targphys.h \
 /tmp/qemu/fpu/softfloat.h /tmp/qemu/fpu/softfloat-native.h ../cpu-all.h \
 ../qemu-common.h ../cpu-common.h ../bswap.h ../config-host.h ../ioport.h \
 ../exec-all.h ../qemu-log.h ../qemu-lock.h ../softmmu_defs.h \
 ../softmmu_header.h /tmp/qemu/target-i386/svm.h /tmp/qemu/module.h \
 /tmp/qemu/sysemu.h /tmp/qemu/hw/hw.h ../qemu-common.h ../ioport.h \
 /tmp/qemu/hw/irq.h /tmp/qemu/gdbstub.h /tmp/qemu/kvm.h \
 /tmp/qemu/sys-queue.h
/tmp/qemu/qemu-common.h:
/tmp/qemu/config-host.h:
/tmp/qemu/target-i386/cpu.h:
config.h:
../config-host.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../cpu-common.h:
../bswap.h:
../config-host.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
/tmp/qemu/module.h:
/tmp/qemu/sysemu.h:
/tmp/qemu/hw/hw.h:
../qemu-common.h:
../ioport.h:
/tmp/qemu/hw/irq.h:
/tmp/qemu/gdbstub.h:
/tmp/qemu/kvm.h:
/tmp/qemu/sys-queue.h:
