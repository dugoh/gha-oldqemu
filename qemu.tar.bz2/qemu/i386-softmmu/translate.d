translate.o: /tmp/qemu/target-i386/translate.c \
 /tmp/qemu/target-i386/cpu.h config.h ../config-host.h ../cpu-defs.h \
 ../osdep.h ../sys-queue.h ../targphys.h /tmp/qemu/fpu/softfloat.h \
 /tmp/qemu/fpu/softfloat-native.h ../cpu-all.h ../qemu-common.h \
 ../config-host.h /tmp/qemu/target-i386/cpu.h ../module.h ../cpu-common.h \
 ../bswap.h ../ioport.h ../exec-all.h ../qemu-log.h ../qemu-lock.h \
 ../softmmu_defs.h ../softmmu_header.h /tmp/qemu/target-i386/svm.h \
 ../disas.h /tmp/qemu/tcg/tcg-op.h /tmp/qemu/tcg/tcg.h ../qemu-common.h \
 /tmp/qemu/tcg/x86_64/tcg-target.h /tmp/qemu/tcg/tcg-opc.h \
 /tmp/qemu/target-i386/helper.h ../def-helper.h \
 /tmp/qemu/target-i386/ops_sse_header.h ../gen-icount.h
/tmp/qemu/target-i386/cpu.h:
config.h:
../config-host.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../config-host.h:
/tmp/qemu/target-i386/cpu.h:
../module.h:
../cpu-common.h:
../bswap.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
../disas.h:
/tmp/qemu/tcg/tcg-op.h:
/tmp/qemu/tcg/tcg.h:
../qemu-common.h:
/tmp/qemu/tcg/x86_64/tcg-target.h:
/tmp/qemu/tcg/tcg-opc.h:
/tmp/qemu/target-i386/helper.h:
../def-helper.h:
/tmp/qemu/target-i386/ops_sse_header.h:
../gen-icount.h:
