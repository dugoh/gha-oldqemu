op_helper.o: /tmp/qemu/target-i386/op_helper.c \
 /tmp/qemu/target-i386/exec.h config.h ../config-host.h ../dyngen-exec.h \
 ../cpu-defs.h ../osdep.h ../sys-queue.h ../targphys.h ../qemu-common.h \
 ../qemu-log.h /tmp/qemu/target-i386/cpu.h /tmp/qemu/fpu/softfloat.h \
 /tmp/qemu/fpu/softfloat-native.h ../cpu-all.h ../qemu-common.h \
 ../cpu-common.h ../bswap.h ../config-host.h ../ioport.h ../exec-all.h \
 ../qemu-log.h ../qemu-lock.h ../softmmu_defs.h ../softmmu_header.h \
 /tmp/qemu/target-i386/svm.h /tmp/qemu/target-i386/helper.h \
 ../def-helper.h /tmp/qemu/target-i386/ops_sse_header.h ../softmmu_exec.h \
 ../host-utils.h ../softmmu_template.h /tmp/qemu/target-i386/ops_sse.h \
 /tmp/qemu/target-i386/helper_template.h
/tmp/qemu/target-i386/exec.h:
config.h:
../config-host.h:
../dyngen-exec.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
../qemu-common.h:
../qemu-log.h:
/tmp/qemu/target-i386/cpu.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../cpu-common.h:
../bswap.h:
../config-host.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
/tmp/qemu/target-i386/helper.h:
../def-helper.h:
/tmp/qemu/target-i386/ops_sse_header.h:
../softmmu_exec.h:
../host-utils.h:
../softmmu_template.h:
/tmp/qemu/target-i386/ops_sse.h:
/tmp/qemu/target-i386/helper_template.h:
