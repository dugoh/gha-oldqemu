acpi.o: /tmp/qemu/hw/acpi.c /tmp/qemu/hw/hw.h ../qemu-common.h \
 ../config-host.h /tmp/qemu/target-i386/cpu.h config.h ../config-host.h \
 ../cpu-defs.h ../osdep.h ../sys-queue.h ../targphys.h \
 /tmp/qemu/fpu/softfloat.h /tmp/qemu/fpu/softfloat-native.h ../cpu-all.h \
 ../qemu-common.h ../cpu-common.h ../bswap.h ../ioport.h ../exec-all.h \
 ../qemu-log.h ../qemu-lock.h ../softmmu_defs.h ../softmmu_header.h \
 /tmp/qemu/target-i386/svm.h ../module.h ../ioport.h /tmp/qemu/hw/irq.h \
 /tmp/qemu/hw/pc.h /tmp/qemu/hw/pci.h /tmp/qemu/hw/qdev.h ../sys-queue.h \
 /tmp/qemu/hw/isa.h /tmp/qemu/hw/pci_ids.h ../qemu-timer.h ../sysemu.h \
 /tmp/qemu/hw/i2c.h /tmp/qemu/hw/smbus.h ../kvm.h
/tmp/qemu/hw/hw.h:
../qemu-common.h:
../config-host.h:
/tmp/qemu/target-i386/cpu.h:
config.h:
../config-host.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../cpu-common.h:
../bswap.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
../module.h:
../ioport.h:
/tmp/qemu/hw/irq.h:
/tmp/qemu/hw/pc.h:
/tmp/qemu/hw/pci.h:
/tmp/qemu/hw/qdev.h:
../sys-queue.h:
/tmp/qemu/hw/isa.h:
/tmp/qemu/hw/pci_ids.h:
../qemu-timer.h:
../sysemu.h:
/tmp/qemu/hw/i2c.h:
/tmp/qemu/hw/smbus.h:
../kvm.h:
