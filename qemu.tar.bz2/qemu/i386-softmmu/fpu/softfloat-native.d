fpu/softfloat-native.o: /tmp/qemu/fpu/softfloat-native.c \
 /tmp/qemu/fpu/softfloat.h config.h ../config-host.h \
 /tmp/qemu/fpu/softfloat-native.h
/tmp/qemu/fpu/softfloat.h:
config.h:
../config-host.h:
/tmp/qemu/fpu/softfloat-native.h:
