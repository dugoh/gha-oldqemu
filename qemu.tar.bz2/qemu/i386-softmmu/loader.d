loader.o: /tmp/qemu/loader.c /tmp/qemu/qemu-common.h \
 /tmp/qemu/config-host.h /tmp/qemu/target-i386/cpu.h config.h \
 ../config-host.h ../cpu-defs.h ../osdep.h ../sys-queue.h ../targphys.h \
 /tmp/qemu/fpu/softfloat.h /tmp/qemu/fpu/softfloat-native.h ../cpu-all.h \
 ../qemu-common.h ../cpu-common.h ../bswap.h ../config-host.h ../ioport.h \
 ../exec-all.h ../qemu-log.h ../qemu-lock.h ../softmmu_defs.h \
 ../softmmu_header.h /tmp/qemu/target-i386/svm.h /tmp/qemu/module.h \
 /tmp/qemu/disas.h /tmp/qemu/sysemu.h /tmp/qemu/uboot_image.h \
 /tmp/qemu/elf.h /tmp/qemu/elf_ops.h
/tmp/qemu/qemu-common.h:
/tmp/qemu/config-host.h:
/tmp/qemu/target-i386/cpu.h:
config.h:
../config-host.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../cpu-common.h:
../bswap.h:
../config-host.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
/tmp/qemu/module.h:
/tmp/qemu/disas.h:
/tmp/qemu/sysemu.h:
/tmp/qemu/uboot_image.h:
/tmp/qemu/elf.h:
/tmp/qemu/elf_ops.h:
