device-hotplug.o: /tmp/qemu/hw/device-hotplug.c /tmp/qemu/hw/hw.h \
 ../qemu-common.h ../config-host.h /tmp/qemu/target-i386/cpu.h config.h \
 ../config-host.h ../cpu-defs.h ../osdep.h ../sys-queue.h ../targphys.h \
 /tmp/qemu/fpu/softfloat.h /tmp/qemu/fpu/softfloat-native.h ../cpu-all.h \
 ../qemu-common.h ../cpu-common.h ../bswap.h ../ioport.h ../exec-all.h \
 ../qemu-log.h ../qemu-lock.h ../softmmu_defs.h ../softmmu_header.h \
 /tmp/qemu/target-i386/svm.h ../module.h ../ioport.h /tmp/qemu/hw/irq.h \
 /tmp/qemu/hw/boards.h /tmp/qemu/hw/qdev.h ../sys-queue.h ../net.h \
 ../block_int.h ../block.h ../qemu-aio.h ../qemu-char.h ../qemu-option.h \
 ../sysemu.h
/tmp/qemu/hw/hw.h:
../qemu-common.h:
../config-host.h:
/tmp/qemu/target-i386/cpu.h:
config.h:
../config-host.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../cpu-common.h:
../bswap.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
../module.h:
../ioport.h:
/tmp/qemu/hw/irq.h:
/tmp/qemu/hw/boards.h:
/tmp/qemu/hw/qdev.h:
../sys-queue.h:
../net.h:
../block_int.h:
../block.h:
../qemu-aio.h:
../qemu-char.h:
../qemu-option.h:
../sysemu.h:
