monitor.o: /tmp/qemu/monitor.c /tmp/qemu/hw/hw.h ../qemu-common.h \
 ../config-host.h /tmp/qemu/target-i386/cpu.h config.h ../config-host.h \
 ../cpu-defs.h ../osdep.h ../sys-queue.h ../targphys.h \
 /tmp/qemu/fpu/softfloat.h /tmp/qemu/fpu/softfloat-native.h ../cpu-all.h \
 ../qemu-common.h ../cpu-common.h ../bswap.h ../ioport.h ../exec-all.h \
 ../qemu-log.h ../qemu-lock.h ../softmmu_defs.h ../softmmu_header.h \
 /tmp/qemu/target-i386/svm.h ../module.h ../ioport.h /tmp/qemu/hw/irq.h \
 /tmp/qemu/hw/qdev.h /tmp/qemu/hw/hw.h ../sys-queue.h /tmp/qemu/hw/usb.h \
 ../block.h ../qemu-aio.h ../qemu-char.h ../qemu-option.h \
 /tmp/qemu/hw/pcmcia.h /tmp/qemu/hw/pc.h /tmp/qemu/hw/pci.h \
 /tmp/qemu/hw/qdev.h /tmp/qemu/hw/isa.h /tmp/qemu/hw/pci_ids.h \
 /tmp/qemu/hw/watchdog.h /tmp/qemu/gdbstub.h /tmp/qemu/net.h \
 /tmp/qemu/sys-queue.h /tmp/qemu/qemu-common.h /tmp/qemu/qemu-char.h \
 /tmp/qemu/sysemu.h /tmp/qemu/monitor.h /tmp/qemu/block.h \
 /tmp/qemu/readline.h /tmp/qemu/console.h /tmp/qemu/audio/audio.h \
 ../config-host.h /tmp/qemu/disas.h /tmp/qemu/balloon.h \
 /tmp/qemu/cpu-defs.h /tmp/qemu/qemu-timer.h /tmp/qemu/migration.h \
 /tmp/qemu/kvm.h /tmp/qemu/acl.h qemu-monitor.h
/tmp/qemu/hw/hw.h:
../qemu-common.h:
../config-host.h:
/tmp/qemu/target-i386/cpu.h:
config.h:
../config-host.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../cpu-common.h:
../bswap.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
../module.h:
../ioport.h:
/tmp/qemu/hw/irq.h:
/tmp/qemu/hw/qdev.h:
/tmp/qemu/hw/hw.h:
../sys-queue.h:
/tmp/qemu/hw/usb.h:
../block.h:
../qemu-aio.h:
../qemu-char.h:
../qemu-option.h:
/tmp/qemu/hw/pcmcia.h:
/tmp/qemu/hw/pc.h:
/tmp/qemu/hw/pci.h:
/tmp/qemu/hw/qdev.h:
/tmp/qemu/hw/isa.h:
/tmp/qemu/hw/pci_ids.h:
/tmp/qemu/hw/watchdog.h:
/tmp/qemu/gdbstub.h:
/tmp/qemu/net.h:
/tmp/qemu/sys-queue.h:
/tmp/qemu/qemu-common.h:
/tmp/qemu/qemu-char.h:
/tmp/qemu/sysemu.h:
/tmp/qemu/monitor.h:
/tmp/qemu/block.h:
/tmp/qemu/readline.h:
/tmp/qemu/console.h:
/tmp/qemu/audio/audio.h:
../config-host.h:
/tmp/qemu/disas.h:
/tmp/qemu/balloon.h:
/tmp/qemu/cpu-defs.h:
/tmp/qemu/qemu-timer.h:
/tmp/qemu/migration.h:
/tmp/qemu/kvm.h:
/tmp/qemu/acl.h:
qemu-monitor.h:
