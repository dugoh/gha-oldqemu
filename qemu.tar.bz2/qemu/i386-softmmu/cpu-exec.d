cpu-exec.o: /tmp/qemu/cpu-exec.c config.h ../config-host.h \
 /tmp/qemu/target-i386/exec.h ../dyngen-exec.h ../cpu-defs.h ../osdep.h \
 ../sys-queue.h ../targphys.h ../qemu-common.h ../qemu-log.h \
 /tmp/qemu/target-i386/cpu.h /tmp/qemu/fpu/softfloat.h \
 /tmp/qemu/fpu/softfloat-native.h ../cpu-all.h ../qemu-common.h \
 ../cpu-common.h ../bswap.h ../config-host.h ../ioport.h ../exec-all.h \
 ../qemu-log.h ../qemu-lock.h ../softmmu_defs.h ../softmmu_header.h \
 /tmp/qemu/target-i386/svm.h /tmp/qemu/target-i386/helper.h \
 ../def-helper.h /tmp/qemu/target-i386/ops_sse_header.h ../softmmu_exec.h \
 /tmp/qemu/disas.h /tmp/qemu/qemu-common.h /tmp/qemu/tcg/tcg.h \
 /tmp/qemu/tcg/x86_64/tcg-target.h /tmp/qemu/tcg/tcg-opc.h \
 /tmp/qemu/kvm.h /tmp/qemu/sys-queue.h /tmp/qemu/hostregs_helper.h
config.h:
../config-host.h:
/tmp/qemu/target-i386/exec.h:
../dyngen-exec.h:
../cpu-defs.h:
../osdep.h:
../sys-queue.h:
../targphys.h:
../qemu-common.h:
../qemu-log.h:
/tmp/qemu/target-i386/cpu.h:
/tmp/qemu/fpu/softfloat.h:
/tmp/qemu/fpu/softfloat-native.h:
../cpu-all.h:
../qemu-common.h:
../cpu-common.h:
../bswap.h:
../config-host.h:
../ioport.h:
../exec-all.h:
../qemu-log.h:
../qemu-lock.h:
../softmmu_defs.h:
../softmmu_header.h:
/tmp/qemu/target-i386/svm.h:
/tmp/qemu/target-i386/helper.h:
../def-helper.h:
/tmp/qemu/target-i386/ops_sse_header.h:
../softmmu_exec.h:
/tmp/qemu/disas.h:
/tmp/qemu/qemu-common.h:
/tmp/qemu/tcg/tcg.h:
/tmp/qemu/tcg/x86_64/tcg-target.h:
/tmp/qemu/tcg/tcg-opc.h:
/tmp/qemu/kvm.h:
/tmp/qemu/sys-queue.h:
/tmp/qemu/hostregs_helper.h:
