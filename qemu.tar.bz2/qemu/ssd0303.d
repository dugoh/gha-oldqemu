ssd0303.o: /tmp/qemu/hw/ssd0303.c /tmp/qemu/hw/i2c.h /tmp/qemu/hw/qdev.h \
 /tmp/qemu/hw/hw.h qemu-common.h config-host.h osdep.h bswap.h module.h \
 ioport.h qemu-common.h /tmp/qemu/hw/irq.h sys-queue.h console.h \
 qemu-char.h sys-queue.h
/tmp/qemu/hw/i2c.h:
/tmp/qemu/hw/qdev.h:
/tmp/qemu/hw/hw.h:
qemu-common.h:
config-host.h:
osdep.h:
bswap.h:
module.h:
ioport.h:
qemu-common.h:
/tmp/qemu/hw/irq.h:
sys-queue.h:
console.h:
qemu-char.h:
sys-queue.h:
