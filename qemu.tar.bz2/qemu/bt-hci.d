bt-hci.o: /tmp/qemu/hw/bt-hci.c qemu-common.h config-host.h osdep.h \
 bswap.h module.h qemu-timer.h /tmp/qemu/hw/usb.h block.h qemu-aio.h \
 qemu-common.h qemu-char.h sys-queue.h qemu-option.h net.h \
 /tmp/qemu/hw/bt.h
qemu-common.h:
config-host.h:
osdep.h:
bswap.h:
module.h:
qemu-timer.h:
/tmp/qemu/hw/usb.h:
block.h:
qemu-aio.h:
qemu-common.h:
qemu-char.h:
sys-queue.h:
qemu-option.h:
net.h:
/tmp/qemu/hw/bt.h:
