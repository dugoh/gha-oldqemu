ssd0323.o: /tmp/qemu/hw/ssd0323.c /tmp/qemu/hw/ssi.h /tmp/qemu/hw/qdev.h \
 /tmp/qemu/hw/hw.h qemu-common.h config-host.h osdep.h bswap.h module.h \
 ioport.h qemu-common.h /tmp/qemu/hw/irq.h sys-queue.h console.h \
 qemu-char.h sys-queue.h
/tmp/qemu/hw/ssi.h:
/tmp/qemu/hw/qdev.h:
/tmp/qemu/hw/hw.h:
qemu-common.h:
config-host.h:
osdep.h:
bswap.h:
module.h:
ioport.h:
qemu-common.h:
/tmp/qemu/hw/irq.h:
sys-queue.h:
console.h:
qemu-char.h:
sys-queue.h:
