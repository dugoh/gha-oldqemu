curses.o: curses.c qemu-common.h config-host.h osdep.h bswap.h module.h \
 console.h qemu-char.h sys-queue.h sysemu.h curses_keys.h keymaps.h
qemu-common.h:
config-host.h:
osdep.h:
bswap.h:
module.h:
console.h:
qemu-char.h:
sys-queue.h:
sysemu.h:
curses_keys.h:
keymaps.h:
